This is a copy of the python3_sklearn public dropin environment from the `datarobot-user-models` repo.

In the future, this script should probably use that directly.
